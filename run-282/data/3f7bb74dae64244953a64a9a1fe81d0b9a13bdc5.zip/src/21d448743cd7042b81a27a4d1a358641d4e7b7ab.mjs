import { test, expect } from "./coverage-fixture.mjs";
import { URLS, CGI } from "./test-urls.mjs";

const BIKE_CGI = `${CGI}/bike-service`;

// ── Bike Service ───────────────────────────────────────────────────────────────

test.describe("bike-service", () => {
  let page;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    jsErrors.length = 0;
    await page.evaluate(() => { try { sessionStorage.clear(); } catch (_) {} });
    await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    try {
      await page.waitForSelector(".bikes .tab", { timeout: 10000 });
      await page.waitForSelector("#bikepanel table", { timeout: 10000 });
      await page.waitForFunction(
        () => !document.getElementById("meta")?.textContent.includes("Loading"),
        { timeout: 10000 },
      );
    } catch (_) {}
  });

  test("shared-inventory-moves-preserve-history-and-consume-stock", async ({ page }) => {
    const originalResponse = await fetch(BIKE_CGI, { cache: "no-store" });
    const original = await originalResponse.json();
    const postStore = async (store) => {
      const response = await fetch(BIKE_CGI, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(store),
      });
      expect(response.ok, `bike-service POST failed with ${response.status}`).toBeTruthy();
    };

    try {
      await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
      await page.waitForSelector(".bikes .tab:not(.add)");

      await page.getByRole("button", { name: "Road Bike", exact: true }).click();
      const chainId = await page.evaluate(() =>
        MODEL.bikes.find((bike) => bike.name === "Road Bike").parts.find((part) => part.name === "Chain").id
      );
      await page.evaluate((id) => {
        const part = MODEL.bikes.find((bike) => bike.name === "Road Bike").parts.find((item) => item.id === id);
        part.emailAlert = true;
        if (!Array.isArray(part.serviceTypes) || !part.serviceTypes.length) {
          part.serviceTypes = [{ id: "move-alert-test", name: "Service", services: [] }];
        }
        part.serviceTypes[0].alertKm = 777;
        part.serviceTypes[0].alertH = 33;
        part.serviceTypes[0].alertTimeN = 3;
        part.serviceTypes[0].alertTimeUnit = "years";
        movePartToInventory(id);
      }, chainId);
      await page.getByRole("button", { name: "Move to inventory" }).click();
      await page.waitForFunction(async () => {
        const store = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        const chain = store.inventory?.find((item) => item.id === "p-chain");
        const service = chain?.serviceTypes?.[0];
        return chain?.emailAlert === true && service?.alertKm === 777 &&
          service?.alertH === 33 && service?.alertTimeN === 3 &&
          service?.alertTimeUnit === "years";
      });
      await expect(page.locator('.sec[data-sid="inventory"]')).toHaveCount(1);

      let store = await (await fetch(BIKE_CGI, { cache: "no-store" })).json();
      const storedChain = store.inventory.find((item) => item.id === "p-chain");
      expect(storedChain.quantity).toBe(1);
      expect(storedChain.emailAlert).toBe(true);
      expect(storedChain.serviceTypes[0]).toMatchObject({
        alertKm: 777,
        alertH: 33,
        alertTimeN: 3,
        alertTimeUnit: "years",
      });
      expect(storedChain.serviceTypes?.[0]?.services?.length).toBeGreaterThan(0);
      expect(storedChain.usageHistory?.at(-1)?.bikeName).toBe("Road Bike");

      await page.getByRole("button", { name: "Gravel Bike", exact: true }).click();
      await page.getByRole("button", { name: "Install on Gravel Bike" }).click();
      await page.getByRole("button", { name: "Install part", exact: true }).click();
      await page.waitForFunction(async () => {
        const saved = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        const chain = saved.bikes.find((bike) => bike.id === "b-gravel")?.parts.find((part) =>
          part.name === "Chain" && part.usageHistory?.some((segment) => segment.bikeName === "Road Bike")
        );
        const service = chain?.serviceTypes?.[0];
        return !saved.inventory?.some((item) => item.id === "p-chain") &&
          chain?.emailAlert === true && service?.alertKm === 777 &&
          service?.alertH === 33 && service?.alertTimeN === 3 &&
          service?.alertTimeUnit === "years";
      });
      await expect(page.locator('.sec[data-sid="inventory"]')).toHaveCount(0);
      store = await (await fetch(BIKE_CGI, { cache: "no-store" })).json();
      const installedChain = store.bikes.find((bike) => bike.id === "b-gravel").parts.find((part) =>
        part.name === "Chain" && part.usageHistory?.some((segment) => segment.bikeName === "Road Bike")
      );
      expect(installedChain.emailAlert).toBe(true);
      expect(installedChain.serviceTypes[0]).toMatchObject({
        alertKm: 777,
        alertH: 33,
        alertTimeN: 3,
        alertTimeUnit: "years",
      });
      expect(installedChain.serviceTypes?.[0]?.services?.length).toBeGreaterThan(0);
      expect(installedChain.usageHistory?.at(-1)?.bikeName).toBe("Road Bike");

      await page.getByRole("button", { name: "＋ Add stock" }).click();
      await page.locator("#stock-name").fill("Inventory test chain");
      await page.locator("#stock-qty").fill("2");
      await page.locator("#stock-distance").fill("120");
      await page.locator("#stock-st-list .st-name").fill("Lubricate");
      await page.getByRole("button", { name: "＋ Add service record" }).click();
      await page.locator(".stock-service-type").fill("Lubricate");
      await page.locator(".stock-service-mileage").fill("60");
      await page.locator(".stock-service-note").fill("recorded before storage");
      await page.getByRole("button", { name: "Add stock", exact: true }).click();
      await page.waitForFunction(async () => {
        const saved = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        return saved.inventory?.some((item) => item.name === "Inventory test chain" && item.quantity === 2);
      });
      await expect(page.locator('.sec[data-sid="inventory"]')).toHaveCount(1);

      await page.getByRole("button", { name: "Road Bike", exact: true }).click();
      const replaceId = await page.evaluate(() =>
        MODEL.bikes.find((bike) => bike.name === "Road Bike").parts.find((part) => part.name === "Rear tyre").id
      );
      await page.evaluate((id) => showReplace(id), replaceId);
      const stockId = await page.locator("#r-stock option").evaluateAll((options) =>
        options.find((option) => option.textContent.includes("Inventory test chain (2 in stock)")).value
      );
      await page.locator("#r-stock").selectOption(stockId);
      await page.evaluate((id) => saveReplace(id), replaceId);
      await page.waitForFunction(async () => {
        const saved = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        return saved.inventory?.some((item) => item.name === "Inventory test chain" && item.quantity === 1);
      });
      store = await (await fetch(BIKE_CGI, { cache: "no-store" })).json();
      const stocked = store.inventory.find((item) => item.name === "Inventory test chain");
      expect(stocked.usageHistory?.[0]?.distance).toBe(120);
      expect(stocked.serviceTypes?.[0]?.services?.[0]?.note).toBe("recorded before storage");
      expect(store.bikes.find((bike) => bike.name === "Road Bike").parts.some((part) =>
        part.name === "Inventory test chain" && part.status !== "archived" &&
        part.usageHistory?.[0]?.distance === 120 &&
        part.serviceTypes?.[0]?.services?.[0]?.note === "recorded before storage"
      )).toBeTruthy();
    } finally {
      await postStore(original);
    }
  });

  test("moving-between-archive-and-inventory-preserves-part-data", async ({ page }) => {
    const original = await (await fetch(BIKE_CGI, { cache: "no-store" })).json();
    const postStore = async (store) => {
      const response = await fetch(BIKE_CGI, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(store),
      });
      expect(response.ok, `bike-service POST failed with ${response.status}`).toBeTruthy();
    };
    const partName = `Reversible archive part ${Date.now()}`;
    const seeded = JSON.parse(JSON.stringify(original));
    const roadBike = seeded.bikes.find((bike) => bike.name === "Road Bike");
    expect(roadBike, "Road Bike fixture is missing").toBeTruthy();
    roadBike.parts.push({
      id: "p-reversible-archive-test",
      name: partName,
      installedDate: "2020-01-01",
      installedMileage: 100,
      currentBikeInstalledDate: "2021-01-01",
      currentBikeInstalledMileage: 200,
      status: "archived",
      archivedDate: "2022-01-01",
      archivedMileage: 350,
      archiveNote: "test archive reason",
      emailAlert: true,
      serviceTypes: [{
        id: "st-reversible-archive-test",
        name: "Test service",
        alertKm: 777,
        alertH: 33,
        alertTimeN: 3,
        alertTimeUnit: "years",
        services: [{ id: "s-reversible-archive-test", date: "2021-06-01", mileage: 275, note: "test service record" }],
      }],
    });

    try {
      await postStore(seeded);
      await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
      await page.waitForSelector(".bikes .tab:not(.add)");
      await page.getByRole("button", { name: "Road Bike", exact: true }).click();
      const archivedRow = page.locator("#bikepanel tr.archived:not(.ridesrow)").filter({ hasText: partName });
      await archivedRow.getByRole("button", { name: "To inventory" }).click();
      await page.waitForFunction(async (name) => {
        const store = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        const item = store.inventory?.find((entry) => entry.name === name);
        return item?.emailAlert === true && item?.usageHistory?.at(-1)?.distance === 150 &&
          item?.archiveHistory?.[0]?.note === "test archive reason" &&
          item?.serviceTypes?.[0]?.services?.[0]?.note === "test service record";
      }, partName);

      let store = await (await fetch(BIKE_CGI, { cache: "no-store" })).json();
      const inventoryPart = store.inventory.find((item) => item.name === partName);
      expect(inventoryPart.quantity).toBe(1);
      expect(inventoryPart.serviceTypes[0]).toMatchObject({
        alertKm: 777,
        alertH: 33,
        alertTimeN: 3,
        alertTimeUnit: "years",
      });
      expect(inventoryPart.archiveHistory[0]).toMatchObject({
        bikeName: "Road Bike",
        date: "2022-01-01",
        mileage: 350,
        note: "test archive reason",
      });
      await page.evaluate(async (name) => {
        const item = MODEL.inventory.find((entry) => entry.name === name);
        item.quantity = 2;
        await persist();
      }, partName);

      await page.getByRole("button", { name: "Gravel Bike", exact: true }).click();
      await page.locator(".inventory-item").filter({ hasText: partName })
        .getByRole("button", { name: "Archive", exact: true }).click();
      const archiveDate = await page.evaluate(() => todayStr());
      await page.locator("#archive-stock-date").fill(archiveDate);
      await page.locator("#archive-stock-mileage").fill("9876");
      await page.locator("#archive-stock-note").fill("retired from inventory");
      await page.getByRole("button", { name: "Archive one item" }).click();
      await page.waitForFunction(async ({ name, date }) => {
        const saved = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        const archived = saved.bikes.find((bike) => bike.name === "Gravel Bike")?.parts
          .find((part) => part.name === name && part.status === "archived");
        return archived?.archivedDate === date &&
          archived?.archivedMileage === 9876 &&
          archived?.archiveNote === "retired from inventory" &&
          archived?.emailAlert === true &&
          archived?.serviceTypes?.[0]?.alertKm === 777 &&
          archived?.serviceTypes?.[0]?.services?.[0]?.note === "test service record" &&
          archived?.usageHistory?.[0]?.bikeName === "Road Bike" &&
          archived?.archiveHistory?.[0]?.note === "test archive reason";
      }, { name: partName, date: archiveDate });

      store = await (await fetch(BIKE_CGI, { cache: "no-store" })).json();
      const archivedAgain = store.bikes.find((bike) => bike.name === "Gravel Bike").parts
        .find((part) => part.name === partName);
      expect(store.inventory.find((item) => item.name === partName).quantity).toBe(1);
      expect(archivedAgain.currentBikeInstalledMileage).toBe(9876);
      expect(archivedAgain.serviceTypes[0]).toMatchObject({
        alertKm: 777,
        alertH: 33,
        alertTimeN: 3,
        alertTimeUnit: "years",
      });
    } finally {
      await postStore(original);
    }
  });

  test("inventory-alerts-are-configurable-and-start-working-after-install", async ({
    page,
  }) => {
    const original = await (await fetch(BIKE_CGI, { cache: "no-store" })).json();
    const postStore = async (store) => {
      const response = await fetch(BIKE_CGI, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(store),
      });
      expect(response.ok, `bike-service POST failed with ${response.status}`).toBeTruthy();
    };
    const partName = `Alert inventory part ${Date.now()}`;

    try {
      await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
      await page.getByRole("button", { name: "Road Bike", exact: true }).click();
      await page.getByRole("button", { name: "＋ Add stock" }).click();
      await page.locator("#stock-name").fill(partName);
      await page.locator("#stock-qty").fill("1");
      await page.locator("#stock-installed").fill("2020-01-01");
      await page.locator("#stock-distance").fill("120");
      const firstType = page.locator("#stock-st-list .st-block").first();
      await firstType.locator(".st-name").fill("Chain service");
      await firstType.locator(".st-km").fill("1000");
      await firstType.locator(".st-h").fill("25");
      await firstType.locator(".st-timen").fill("1");
      await firstType.locator(".st-timeunit").selectOption("weeks");
      await page.getByRole("button", { name: "＋ Add service type" }).click();
      const secondType = page.locator("#stock-st-list .st-block").nth(1);
      await secondType.locator(".st-name").fill("Safety inspection");
      await secondType.locator(".st-km").fill("250");
      await secondType.locator(".st-h").fill("10");
      await page.locator("#stock-email-alert").check();
      await page.getByRole("button", { name: "Add stock", exact: true }).click();

      await page.waitForFunction(async (name) => {
        const saved = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        const item = saved.inventory?.find((entry) => entry.name === name);
        return item?.emailAlert === true && item.serviceTypes?.length === 2;
      }, partName);
      let saved = await (await fetch(BIKE_CGI, { cache: "no-store" })).json();
      const stock = saved.inventory.find((item) => item.name === partName);
      expect(stock.emailAlert).toBe(true);
      expect(stock.serviceTypes).toMatchObject([
        {
          name: "Chain service",
          alertKm: 1000,
          alertH: 25,
          alertTimeN: 1,
          alertTimeUnit: "weeks",
        },
        {
          name: "Safety inspection",
          alertKm: 250,
          alertH: 10,
          alertTimeN: null,
        },
      ]);

      const itemCard = page.locator(".inventory-item").filter({ hasText: partName });
      await itemCard.getByRole("button", { name: "Install on Road Bike" }).click();
      await page.locator("#stock-date").fill("2020-01-01");
      await page.getByRole("button", { name: "Install part", exact: true }).click();
      await page.waitForFunction(async (name) => {
        const data = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        const bike = data.bikes.find((entry) => entry.name === "Road Bike");
        return bike?.parts.some((part) => part.name === name && part.emailAlert === true);
      }, partName);

      saved = await (await fetch(BIKE_CGI, { cache: "no-store" })).json();
      const installed = saved.bikes.find((bike) => bike.name === "Road Bike").parts
        .find((part) => part.name === partName);
      expect(installed.emailAlert).toBe(true);
      expect(installed.serviceTypes).toMatchObject(stock.serviceTypes);
      const pctAfterReinstall = await page.evaluate((partName) => {
        const bike = MODEL.bikes.find((entry) => entry.name === "Road Bike");
        const part = JSON.parse(JSON.stringify(
          bike.parts.find((entry) => entry.name === partName),
        ));
        part.installedDate = "2020-01-01";
        part.currentBikeInstalledDate = todayStr();
        part.currentBikeInstalledMileage = bikeMileage(bike, todayStr());
        return stPct(bike, part, part.serviceTypes[0]);
      }, partName);
      expect(pctAfterReinstall).toBe(0);
      await expect(
        page.locator('.sec[data-sid="service-queue"]').filter({ hasText: partName }),
      ).toContainText("Chain service");
    } finally {
      await postStore(original);
    }
  });

  test.afterAll(async () => { await page.close(); });

  test("no-js-errors", () => {
    expect(jsErrors.length, jsErrors.map((e) => e.message).join("; ")).toBe(0);
  });

  test("meta-not-loading", async () => {
    const text = await page.$eval("#meta", (el) => el.textContent);
    expect(!text.includes("Loading"), `#meta still says Loading`).toBeTruthy();
  });

  test("inventory-section-hidden-when-empty", async () => {
    await expect(page.locator('.sec[data-sid="inventory"]')).toHaveCount(0);
  });

  test("service-queue-includes-all-bikes-sorts-by-urgency-and-hides-without-overdue-work", async () => {
    const result = await page.evaluate(() => {
      const saved = { model: MODEL, selected: selBike, rides: RIDES };
      const today = todayStr();
      const makeBike = (id, name, mileage) => ({
        id, name, gearId: "", baseMileage: mileage, parts: [{
          id: `${id}-chain`, name: "Chain", installedDate: today, installedMileage: 0,
          status: "new", serviceTypes: [{
            id: `${id}-clean`, name: "Clean & Lube", alertKm: 100, alertH: null, services: [],
          }],
        }],
      });
      try {
        RIDES = [];
        MODEL = {
          version: 1,
          bikes: [makeBike("queue-road", "Road Bike", 120), makeBike("queue-gravel", "Gravel Bike", 85)],
          inventory: [],
        };
        selBike = "queue-road";
        render();
        const queue = document.querySelector('.sec[data-sid="service-queue"]');
        const rows = queue
          ? Array.from(queue.querySelectorAll("tbody tr")).map((row) => ({
            text: row.textContent.trim(),
            state: row.querySelector("td")?.classList.contains("queue-due") ? "overdue" : "upcoming",
          }))
          : [];

        queue.querySelector('[data-queue-bike="queue-gravel"]').click();
        const viewBikeSelectsCorrectBike = selBike === "queue-gravel";
        MODEL.bikes[0].baseMileage = 20;
        render();
        return {
          rows,
          viewBikeSelectsCorrectBike,
          upcomingOnlyStillHidden: !document.querySelector('.sec[data-sid="service-queue"]'),
        };
      } finally {
        MODEL = saved.model;
        selBike = saved.selected;
        RIDES = saved.rides;
        render();
      }
    });

    expect(result.rows).toHaveLength(2);
    expect(result.rows[0].text).toContain("Road Bike");
    expect(result.rows[0].state).toBe("overdue");
    expect(result.rows[1].text).toContain("Gravel Bike");
    expect(result.rows[1].state).toBe("upcoming");
    expect(result.viewBikeSelectsCorrectBike).toBeTruthy();
    expect(result.upcomingOnlyStillHidden).toBeTruthy();
  });

  test("bike-tabs-present", async () => {
    const n = await page.$$eval(".bikes .tab:not(.add)", (els) => els.length);
    expect(n >= 4, `expected >= 4 bike tabs, got ${n}`).toBeTruthy();
  });

  test("no-duplicate-bike-tabs", async () => {
    const labels = await page.$$eval(".bikes .tab:not(.add)", (els) =>
      els.map((e) => e.textContent.trim()),
    );
    const dupes = labels.filter((l, i) => labels.indexOf(l) !== i);
    expect(dupes.length, `duplicate bike tabs: ${JSON.stringify(dupes)}`).toBe(0);
  });

  test("no-duplicate-gear-options", async () => {
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Kross"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .btn.sm", { timeout: 5000 });
    await page.evaluate(() => {
      const btns = document.querySelectorAll("#bikepanel .btn.sm");
      const edit = Array.from(btns).find((b) => b.textContent.includes("Edit bike"));
      if (edit) edit.click();
    });
    await page.waitForSelector("#b-gear", { timeout: 3000 });
    const opts = await page.$$eval("#b-gear option", (els) =>
      els.map((o) => o.textContent.replace(/\s*·.*$/, "").trim()),
    );
    const dupes = opts.filter((l, i) => l && opts.indexOf(l) !== i);
    expect(dupes.length, `duplicate gear options: ${JSON.stringify(dupes)}`).toBe(0);
    await page.evaluate(() => { if (typeof closeModal === "function") closeModal(); });
  });

  test("road-bike-tab-exists", async () => {
    const labels = await page.$$eval(".bikes .tab:not(.add)", (els) =>
      els.map((e) => e.textContent.trim()),
    );
    expect(
      labels.some((l) => l.includes("Road Bike")),
      `"Road Bike" not in tabs: ${JSON.stringify(labels)}`,
    ).toBeTruthy();
  });

  test("road-bike-odo-positive", async () => {
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
    const text = await page.$eval("#bikepanel .big", (el) => el.textContent.trim());
    const km = parseFloat(text.replace(/[\s,]/g, "").replace(",", "."));
    expect(km > 0, `expected Road Bike odo > 0 km, got "${text}"`).toBeTruthy();
  });

  test("top-panel-extra-stats", async () => {
    const labels = await page.$$eval(
      "#bikepanel .odo .k",
      (els) => els.map((el) => el.textContent.trim()),
    );
    expect(labels.includes("Elevation"),  `expected "Elevation" in odo labels, got: ${JSON.stringify(labels)}`).toBeTruthy();
    expect(labels.includes("Avg Ride"),   `expected "Avg Ride" in odo labels, got: ${JSON.stringify(labels)}`).toBeTruthy();
    expect(labels.includes("Services"),   `expected "Services" in odo labels, got: ${JSON.stringify(labels)}`).toBeTruthy();
    expect(labels.includes("Parts"),      `expected "Parts" in odo labels, got: ${JSON.stringify(labels)}`).toBeTruthy();
  });

  test("bike-stats-comparison-table", async () => {
    const headings = await page.$$eval("#bikepanel h2", (els) => els.map((el) => el.textContent.trim()));
    expect(
      headings.some((h) => h.includes("Bike Statistics")),
      `expected "Bike Statistics" h2, got: ${JSON.stringify(headings)}`,
    ).toBeTruthy();
    const rows = await page.$$eval(
      "#bikepanel table tbody tr",
      (trs) => trs
        .filter((r) => !r.classList.contains("ridesrow") && !r.classList.contains("archived"))
        .map((r) => Array.from(r.querySelectorAll("td")).map((td) => td.textContent.trim())),
    );
    const distRow = rows.find((r) => r[0] === "Distance");
    expect(distRow, `expected a "Distance" row in the Bike Statistics table`).toBeTruthy();
    const hasPositive = distRow.slice(1).some(function(cell) {
      return parseFloat(cell.replace(/[\s]/g, "")) > 0;
    });
    expect(hasPositive, `expected at least one positive Distance value, got: ${JSON.stringify(distRow)}`).toBeTruthy();
  });

  test("parts-table-has-rows", async () => {
    const n = await page.$$eval(
      "#bikepanel tbody tr:not(.ridesrow)",
      (rows) => rows.length,
    );
    expect(n >= 1, `expected >= 1 part row in Road Bike panel, got ${n}`).toBeTruthy();
  });

  test("archived-part-shows-duration", async () => {
    const archiveRows = await page.$$eval(
      "#bikepanel tr.archived:not(.ridesrow)",
      (rows) => rows.length,
    );
    expect(archiveRows >= 1, `expected >= 1 archived part row, got ${archiveRows}`).toBeTruthy();
    const durText = await page.$eval(
      "#bikepanel tr.archived:not(.ridesrow) td:nth-child(2) .muted",
      (el) => el.textContent.trim(),
    );
    expect(
      /year|month|week|day/.test(durText),
      `expected duration text (year/month/week/day) in archived part, got: "${durText}"`,
    ).toBeTruthy();
  });

  test("time-based-alert-bar-renders", async () => {
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
    const pct = await page.$eval(
      "#bikepanel tbody tr:not(.ridesrow):not(.archived) .svc-pct",
      (el) => el.textContent.trim(),
    );
    expect(pct.endsWith("%"), `expected a % value in .svc-pct, got: "${pct}"`).toBeTruthy();
  });

  test("time-based-alert-shows-days", async () => {
    const sinceCells = await page.$$eval(
      "#bikepanel tbody tr:not(.ridesrow):not(.archived) td:nth-child(5)",
      (els) => els.map((e) => e.textContent),
    );
    const hasDays = sinceCells.some((t) => /\d+ d/.test(t));
    expect(hasDays, `expected at least one "Since service" cell to show days, got: ${JSON.stringify(sinceCells)}`).toBeTruthy();
  });

  test("cost-column-header-present", async () => {
    const headers = await page.$$eval(
      "#bikepanel thead th",
      (ths) => ths.map((th) => th.textContent.trim()),
    );
    expect(headers.includes("Cost"), `expected "Cost" column header, got: ${JSON.stringify(headers)}`).toBeTruthy();
  });

  test("cost-total-block-shown", async () => {
    await page.evaluate(() => {
      const t = Array.from(document.querySelectorAll(".bikes .tab:not(.add)")).find(
        (el) => el.textContent.includes("Road Bike"),
      );
      if (t) t.click();
    });
    try {
      await page.waitForFunction(() => !!document.querySelector(".cost-block"), { timeout: 5000 });
    } catch (_) {}
    const block = await page.$(".cost-block");
    expect(block, "expected .cost-block to be present when costs are recorded").toBeTruthy();
    const text = await page.$eval(".cost-block .cost-total", (el) => el.textContent.trim());
    expect(/\d/.test(text), `expected a numeric value in .cost-total, got: "${text}"`).toBeTruthy();
  });

  test("cost-total-includes-currency", async () => {
    const text = await page.$eval(".cost-block .cost-total", (el) => el.textContent.trim());
    expect(/PLN/i.test(text), `expected currency code (PLN) in cost total, got: "${text}"`).toBeTruthy();
  });

  test("cost-split-parts-and-service", async () => {
    const text = await page.$eval(".cost-block", (el) => el.textContent);
    expect(/parts/i.test(text), `expected "parts" label in cost split line, got: "${text}"`).toBeTruthy();
    expect(/service/i.test(text), `expected "service" label in cost split line, got: "${text}"`).toBeTruthy();
  });

  test("cost-split-shows-correct-amounts", async () => {
    const text = await page.$eval(".cost-block", (el) => el.textContent);
    expect(/49[.,]90/.test(text), `expected part cost 49.90 in cost block, got: "${text}"`).toBeTruthy();
    expect(/5[.,]50/.test(text), `expected service cost 5.50 in cost block, got: "${text}"`).toBeTruthy();
  });

  test("cost-cell-shows-part-cost", async () => {
    const costCells = await page.$$eval(
      "#bikepanel tbody tr:not(.ridesrow):not(.archived) td:nth-child(6)",
      (els) => els.map((e) => e.textContent.trim()),
    );
    const hasValue = costCells.some((t) => /\d/.test(t) && !t.includes("—"));
    expect(hasValue, `expected at least one cost cell with a numeric value, got: ${JSON.stringify(costCells)}`).toBeTruthy();
  });

  test("cost-modal-label-has-currency", async () => {
    await page.evaluate(() => {
      if (typeof showAddPart === "function") showAddPart();
    });
    await page.waitForSelector("#p-cost", { timeout: 3000 });
    const labelText = await page.evaluate(() => {
      const input = document.getElementById("p-cost");
      if (!input) return "";
      const label = input.previousElementSibling;
      return label ? label.textContent.trim() : "";
    });
    expect(/PLN/i.test(labelText), `expected currency code (PLN) in purchase cost label, got: "${labelText}"`).toBeTruthy();
    await page.evaluate(() => { if (typeof closeModal === "function") closeModal(); });
  });

  test("move-option-hidden-with-only-one-bike", async () => {
    const visible = await page.evaluate(() => {
      const bikes = MODEL.bikes;
      const selected = selBike;
      const singleBike = bikes.find((b) => b.name === "Road Bike") || bikes[0];
      MODEL.bikes = [singleBike];
      selBike = singleBike.id;
      render();
      const hasMove = !!document.querySelector('#bikepanel button[onclick*="showMovePart"]');
      MODEL.bikes = bikes;
      selBike = selected;
      render();
      return hasMove;
    });
    expect(visible, "Move action should be hidden when there is only one bike").toBe(false);
  });

  test("moving-part-preserves-history-costs-and-usage", async () => {
    const original = await page.evaluate(async () => fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json()));
    await page.evaluate((snapshot) => {
      MODEL = snapshot;
      if (!Array.isArray(MODEL.inventory)) MODEL.inventory = [];
      MODEL.bikes.forEach((bike) => {
        if (!Array.isArray(bike.parts)) bike.parts = [];
        bike.parts.forEach(migratePart);
      });
      render();
    }, original);
    const before = await page.evaluate(() => {
      const source = MODEL.bikes.find((b) => b.name === "Road Bike");
      const target = MODEL.bikes.find((b) => b.name === "Gravel Bike");
      return { sourceId: source?.id, targetId: target?.id, part: source?.parts?.find((p) => p.id === "p-chain") };
    });
    expect(before.part, "Road Bike chain fixture is missing").toBeTruthy();
    expect(before.targetId, "Gravel Bike fixture is missing").toBeTruthy();
    const originalServices = JSON.parse(JSON.stringify(before.part.serviceTypes));
    const originalCost = before.part.cost;

    try {
      await page.evaluate(() => {
        const tab = Array.from(document.querySelectorAll(".bikes .tab:not(.add)")).find((el) => el.textContent.includes("Road Bike"));
        if (tab) tab.click();
      });
      await page.evaluate(() => {
        const button = Array.from(document.querySelectorAll('#bikepanel .sec[data-sid="parts"] button[onclick*="showMovePart"]'))
          .find((el) => el.getAttribute("onclick").includes("'p-chain'"));
        if (!button) throw new Error("Road Bike chain Move button is missing");
        button.click();
      });
      await page.selectOption("#move-target", before.targetId);
      await page.getByRole("button", { name: "Move part" }).click();
      await page.waitForFunction(async ({ sourceId, targetId }) => {
        const saved = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        return !saved.bikes.find((b) => b.id === sourceId)?.parts?.some((p) => p.id === "p-chain") &&
          saved.bikes.find((b) => b.id === targetId)?.parts?.some((p) => p.id === "p-chain" && p.usageHistory?.length);
      }, { sourceId: before.sourceId, targetId: before.targetId });

      const moved = await page.evaluate(async ({ targetId }) => {
        const saved = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        return saved.bikes.find((b) => b.id === targetId)?.parts?.find((p) => p.id === "p-chain");
      }, { targetId: before.targetId });
      expect(moved, "moved chain was not found on Gravel Bike").toBeTruthy();
      expect(moved.usageHistory[0].bikeId).toBe(before.sourceId);
      expect(moved.usageHistory[0].distance).toBeGreaterThan(0);
      expect(moved.usageHistory[0].time).toBeGreaterThan(0);
      expect(moved.serviceTypes).toEqual(originalServices);
      expect(moved.cost).toBe(originalCost);
      expect(moved.installedDate).toBe(before.part.installedDate);
      expect(moved.currentBikeInstalledMileage).toBeDefined();
    } finally {
      await page.evaluate(async (snapshot) => {
        await fetch("/cgi-bin/bike-service", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(snapshot),
        });
      }, original);
      await page.reload({ waitUntil: "networkidle", timeout: 20000 });
    }
  });
});

// ── Bike Input Step and Odo ────────────────────────────────────────────────────

test.describe("bike-input-step-and-odo", () => {
  let page;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    jsErrors.length = 0;
    await page.evaluate(() => { try { sessionStorage.clear(); } catch (_) {} });
    await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    try {
      await page.waitForSelector(".bikes .tab", { timeout: 10000 });
      await page.waitForFunction(
        () => !document.getElementById("meta")?.textContent.includes("Loading"),
        { timeout: 10000 },
      );
    } catch (_) {}
  });

  test.afterAll(async () => { await page.close(); });

  test("add-part-mileage-step-is-1", async () => {
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
    await page.evaluate(() => { if (typeof showAddPart === "function") showAddPart(); });
    await page.waitForSelector("#f-mileage", { timeout: 3000 });
    const step = await page.$eval("#f-mileage", (el) => el.getAttribute("step"));
    expect(step, `expected #f-mileage step="1", got "${step}"`).toBe("1");
    await page.evaluate(() => { if (typeof closeModal === "function") closeModal(); });
  });

  test("add-part-alert-km-step-is-1", async () => {
    await page.evaluate(() => { if (typeof showAddPart === "function") showAddPart(); });
    await page.waitForSelector(".st-km", { timeout: 3000 });
    const step = await page.$eval(".st-km", (el) => el.getAttribute("step"));
    expect(step, `expected .st-km step="1", got "${step}"`).toBe("1");
    await page.evaluate(() => { if (typeof closeModal === "function") closeModal(); });
  });

  test("add-part-alert-hours-step-is-1", async () => {
    await page.evaluate(() => { if (typeof showAddPart === "function") showAddPart(); });
    await page.waitForSelector(".st-h", { timeout: 3000 });
    const step = await page.$eval(".st-h", (el) => el.getAttribute("step"));
    expect(step, `expected .st-h step="1", got "${step}"`).toBe("1");
    await page.evaluate(() => { if (typeof closeModal === "function") closeModal(); });
  });

  test("edit-bike-base-mileage-step-is-1", async () => {
    await page.evaluate(() => {
      const btns = document.querySelectorAll("#bikepanel .btn.sm");
      const edit = Array.from(btns).find((b) => b.textContent.includes("Edit bike"));
      if (edit) edit.click();
    });
    await page.waitForSelector("#b-base", { timeout: 3000 });
    const step = await page.$eval("#b-base", (el) => el.getAttribute("step"));
    expect(step, `expected #b-base step="1", got "${step}"`).toBe("1");
    await page.evaluate(() => { if (typeof closeModal === "function") closeModal(); });
  });

  test("odo-test-bike-tab-present", async () => {
    const labels = await page.$$eval(".bikes .tab:not(.add)", (els) =>
      els.map((e) => e.textContent.trim()),
    );
    expect(
      labels.some((l) => l.includes("Odo Test Bike")),
      `"Odo Test Bike" not in tabs: ${JSON.stringify(labels)}`,
    ).toBeTruthy();
  });

  test("ridden-since-install-includes-base-mileage", async () => {
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Odo Test Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel table", { timeout: 5000 });
    const riddenText = await page.$eval(
      '#bikepanel .sec[data-sid="parts"] tbody tr:not(.ridesrow) td:nth-child(3)',
      (el) => el.textContent.trim(),
    );
    const km = parseFloat(riddenText.replace(/[\s ]/g, "").replace(",", "."));
    expect(
      km > 4000,
      `expected ridden-since-install > 4000 km (baseMileage included), got ${km} from "${riddenText}"`,
    ).toBeTruthy();
  });

  test("alert-pct-includes-base-mileage", async () => {
    const pctText = await page.$eval(
      "#bikepanel tbody tr:not(.ridesrow):not(.archived) .svc-pct",
      (el) => el.textContent.trim(),
    );
    const pct = parseFloat(pctText);
    expect(
      pct >= 100,
      `expected alert pct >= 100% (baseMileage included in calc), got ${pct}% from "${pctText}"`,
    ).toBeTruthy();
  });
});

// ── Bike Service Part Replacement ─────────────────────────────────────────────

test.describe("bike-service-parts", () => {
  let page, partsBefore;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    jsErrors.length = 0;
    await page.evaluate(() => { try { sessionStorage.clear(); } catch (_) {} });
    await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    try {
      await page.waitForSelector(".bikes .tab", { timeout: 10000 });
      await page.waitForSelector("#bikepanel table", { timeout: 10000 });
      await page.waitForFunction(
        () => !document.getElementById("meta")?.textContent.includes("Loading"),
        { timeout: 10000 },
      );
    } catch (_) {}
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
    partsBefore = await page.$$eval(
      "#bikepanel tbody tr:not(.ridesrow)",
      (rows) => rows.length,
    );
  });

  test.afterAll(async () => { await page.close(); });

  test("part-delete-button-exists", async () => {
    const deleteBtn = await page.$(
      '#bikepanel tbody tr:not(.ridesrow) button[onclick*="deletePart"]',
    );
    expect(deleteBtn, "delete button for first part not found").toBeTruthy();
    expect(partsBefore >= 1, "should have at least 1 part").toBeTruthy();
  });

  test("part-deletion-persists", async () => {
    await page.evaluate(() => { window.confirm = () => true; });
    const deleteBtn = await page.$(
      '#bikepanel tbody tr:not(.ridesrow) button[onclick*="deletePart"]',
    );
    if (deleteBtn) {
      await deleteBtn.click();
    }
    await page.evaluate(() => new Promise((resolve) => setTimeout(resolve, 500)));
    const partsAfter = await page.$$eval(
      "#bikepanel tbody tr:not(.ridesrow)",
      (rows) => rows.length,
    );
    expect(
      partsAfter < partsBefore,
      `expected parts count to decrease, before: ${partsBefore}, after: ${partsAfter}`,
    ).toBeTruthy();
  });
});

// ── Bike Service Notifications ─────────────────────────────────────────────────

test.describe("bike-service-notifications", () => {
  let page;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    jsErrors.length = 0;
    await page.evaluate(() => { try { sessionStorage.clear(); } catch (_) {} });
    await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    try {
      await page.waitForSelector(".bikes .tab", { timeout: 10000 });
      await page.waitForSelector("#bikepanel table", { timeout: 10000 });
      await page.waitForFunction(
        () => !document.getElementById("meta")?.textContent.includes("Loading"),
        { timeout: 10000 },
      );
    } catch (_) {}
  });

  test.afterAll(async () => { await page.close(); });

  test("error-element-exists", async () => {
    const errEl = await page.$("#err");
    expect(errEl, "#err element not found").toBeTruthy();
    const text = await page.$eval("#err", (el) => el.textContent.trim());
    expect(text, `#err should be initially empty, got: "${text}"`).toBe("");
  });

  test("error-clears-on-load", async () => {
    let err = await page.$eval("#err", (el) => el.textContent.trim());
    expect(err, "error should start empty").toBe("");
    await page.evaluate(() => {
      document.getElementById("err").textContent = "Test error message";
    });
    let errSet = await page.$eval("#err", (el) => el.textContent.trim());
    expect(errSet.includes("Test error"), `error should contain test message, got: "${errSet}"`).toBeTruthy();
    await page.reload({ waitUntil: "networkidle", timeout: 20000 });
    let errAfter = await page.$eval("#err", (el) => el.textContent.trim());
    expect(errAfter, `error should be cleared after reload, got: "${errAfter}"`).toBe("");
  });

  test("error-appears-in-modal-flow", async () => {
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
    const parts = await page.$$('#bikepanel tbody tr:not(.ridesrow) button[onclick*="showPart"]');
    if (parts.length > 0) {
      await parts[0].click();
      await page.evaluate(() => new Promise((resolve) => setTimeout(resolve, 200)));
    }
    const err = await page.$eval("#err", (el) => el.textContent.trim());
    expect(typeof err === "string", "error should be string or empty").toBeTruthy();
  });
});

// ── Bike Modal CRUD ────────────────────────────────────────────────────────────

test.describe("bike-modal-crud", () => {
  let page;
  const jsErrors = [];
  let testBikeName;

  test.beforeAll(async ({ browser }) => {
    testBikeName = `TestBike-${Date.now()}`;
    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    jsErrors.length = 0;
    await page.evaluate(() => { try { sessionStorage.clear(); } catch (_) {} });
    await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    try {
      await page.waitForSelector(".bikes .tab", { timeout: 10000 });
      await page.waitForFunction(
        () => !document.getElementById("meta")?.textContent.includes("Loading"),
        { timeout: 10000 },
      );
    } catch (_) {}
  });

  test.afterAll(async () => { await page.close(); });

  test("add-bike-modal-opens", async () => {
    await page.evaluate(() => showAddBike());
    await page.waitForSelector("#b-name", { timeout: 3000 });
    const nameInput = await page.$("#b-name");
    expect(nameInput, "#b-name input not found in add-bike modal").toBeTruthy();
  });

  test("add-bike-creates-tab", async () => {
    await page.$eval("#b-name", (el, name) => { el.value = name; }, testBikeName);
    await page.evaluate(() => saveBike(null));
    await page.evaluate(() => new Promise((r) => setTimeout(r, 800)));
    const tabs = await page.$$eval(".bikes .tab:not(.add)", (els) =>
      els.map((el) => el.textContent.trim()),
    );
    expect(
      tabs.some((t) => t.includes(testBikeName)),
      `expected tab with name "${testBikeName}", got: ${JSON.stringify(tabs)}`,
    ).toBeTruthy();
  });

  test("custom-part-vendor-and-model-are-saved-and-suggested", async () => {
    const original = await (await fetch(BIKE_CGI, { cache: "no-store" })).json();
    const partName = `CustomPart-${Date.now()}`;
    const vendor = `CustomVendor-${Date.now()}`;
    try {
      await page.evaluate(() => {
        const tab = Array.from(document.querySelectorAll(".bikes .tab:not(.add)"))
          .find((el) => el.textContent.includes("Road Bike"));
        if (tab) tab.click();
      });
      await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
      await page.evaluate(() => showAddPart());
      await page.locator("#p-name").fill(partName);
      await page.locator("#p-vendor").fill(vendor);
      await page.locator("#p-model").fill("Custom Model 42");
      await page.evaluate(() => savePart(null));
      await page.waitForFunction(async ({ partName, vendor }) => {
        const saved = await fetch("/cgi-bin/bike-service", { cache: "no-store" }).then((r) => r.json());
        const part = saved.bikes.flatMap((bike) => bike.parts || []).find((item) => item.name === partName);
        return part?.vendor === vendor && part?.model === "Custom Model 42" &&
          saved.partNames?.includes(partName) && saved.vendors?.includes(vendor);
      }, { partName, vendor });
      await page.waitForFunction(({ partName, vendor }) =>
        MODEL.partNames.includes(partName) && MODEL.vendors.includes(vendor), { partName, vendor });

      await page.evaluate(() => showAddPart());
      await page.locator("#p-name").fill("An existing value");
      await page.locator("#p-name-choice").selectOption("Chain");
      await expect(page.locator("#p-name")).toHaveValue("Chain");
      await page.locator("#p-name-choice").selectOption(partName);
      await expect(page.locator("#p-name")).toHaveValue(partName);
      await page.locator("#p-vendor").fill("An existing vendor");
      await page.locator("#p-vendor-choice").selectOption(vendor);
      await expect(page.locator("#p-vendor")).toHaveValue(vendor);
      await page.evaluate(() => closeModal());
    } finally {
      await fetch(BIKE_CGI, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(original),
      });
      await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    }
  });

  test("add-part-modal-opens", async () => {
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
    await page.evaluate(() => showAddPart());
    await page.waitForSelector("#p-name", { timeout: 3000 });
    const nameInput = await page.$("#p-name");
    expect(nameInput, "#p-name input not found in add-part modal").toBeTruthy();
  });

  test("add-part-creates-row", async () => {
    const testPartName = `TestPart-${Date.now()}`;
    await page.$eval("#p-name", (el, name) => { el.value = name; }, testPartName);
    const countBefore = await page.$$eval(
      "#bikepanel tbody tr:not(.ridesrow)",
      (rows) => rows.length,
    );
    await page.evaluate(() => savePart(null));
    await page.evaluate(() => new Promise((r) => setTimeout(r, 800)));
    const countAfter = await page.$$eval(
      "#bikepanel tbody tr:not(.ridesrow)",
      (rows) => rows.length,
    );
    expect(
      countAfter > countBefore,
      `expected part count to increase from ${countBefore}, got ${countAfter}`,
    ).toBeTruthy();
  });

  test("delete-bike-removes-tab", async () => {
    await page.evaluate((name) => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      for (const t of tabs) {
        if (t.textContent.trim().includes(name)) { t.click(); break; }
      }
    }, testBikeName);
    await page.evaluate(() => new Promise((r) => setTimeout(r, 300)));
    const tabsBefore = await page.$$eval(".bikes .tab:not(.add)", (els) => els.length);
    await page.evaluate(() => {
      window.confirm = () => true;
      const btn = document.querySelector('button[onclick*="deleteBike"]');
      if (btn) btn.click();
    });
    await page.evaluate(() => new Promise((r) => setTimeout(r, 800)));
    const tabsAfter = await page.$$eval(".bikes .tab:not(.add)", (els) => els.length);
    expect(
      tabsAfter < tabsBefore,
      `expected tab count to decrease from ${tabsBefore}, got ${tabsAfter}`,
    ).toBeTruthy();
  });
});

// ── Email Alert Checkbox ───────────────────────────────────────────────────────

test.describe("email-alert-checkbox", () => {
  let page;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    jsErrors.length = 0;
    await page.evaluate(() => { try { sessionStorage.clear(); } catch (_) {} });
    await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    try {
      await page.waitForSelector(".bikes .tab", { timeout: 10000 });
      await page.waitForFunction(
        () => !document.getElementById("meta")?.textContent.includes("Loading"),
        { timeout: 10000 },
      );
    } catch (_) {}
  });

  test.afterAll(async () => { await page.close(); });

  test("checkbox-always-visible-in-add-part-modal", async () => {
    await page.evaluate(() => {
      if (typeof _CFG !== "undefined") _CFG.emailConfigured = false;
      if (typeof showAddPart === "function") showAddPart();
    });
    await page.waitForSelector("#p-name", { timeout: 3000 });
    const chk = await page.$("#p-email-alert");
    expect(chk, "#p-email-alert checkbox should always be present in add-part modal").toBeTruthy();
    const hint = await page.$('.chk:has(#p-email-alert) .muted');
    expect(hint, "hint span should appear when emailConfigured=false").toBeTruthy();
    await page.evaluate(() => closeModal());
  });

  test("checkbox-hint-hidden-when-email-configured", async () => {
    await page.evaluate(() => {
      if (typeof _CFG !== "undefined") _CFG.emailConfigured = true;
      if (typeof showAddPart === "function") showAddPart();
    });
    await page.waitForSelector("#p-name", { timeout: 3000 });
    const chk = await page.$("#p-email-alert");
    expect(chk, "#p-email-alert checkbox should be present when emailConfigured=true").toBeTruthy();
    const hint = await page.$('.chk:has(#p-email-alert) .muted');
    expect(!hint, "hint span should not appear when emailConfigured=true").toBeTruthy();
    await page.evaluate(() => closeModal());
  });

  test("email-alert-true-persisted", async () => {
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
    const partName = `EmailAlertPart-${Date.now()}`;
    await page.evaluate((name) => {
      if (typeof _CFG !== "undefined") _CFG.emailConfigured = true;
      showAddPart();
    }, partName);
    await page.waitForSelector("#p-name", { timeout: 3000 });
    await page.$eval("#p-name", (el, v) => { el.value = v; }, partName);
    await page.$eval("#p-email-alert", (el) => { el.checked = true; });
    await page.evaluate(() => savePart(null));
    await page.evaluate(() => new Promise((r) => setTimeout(r, 1000)));
    const data = await fetch(BIKE_CGI, { cache: "no-store" }).then((r) => r.json());
    const bike = data.bikes.find((b) => b.name === "Road Bike");
    expect(bike, "Road Bike not found in CGI store").toBeTruthy();
    const newPart = (bike.parts || []).find((p) => p.name === partName);
    expect(newPart, `Part "${partName}" not found in CGI store`).toBeTruthy();
    expect(newPart.emailAlert, `expected emailAlert:true on part, got: ${JSON.stringify(newPart.emailAlert)}`).toBe(true);
    // Cleanup
    const cleanData = await fetch(BIKE_CGI, { cache: "no-store" }).then((r) => r.json());
    const cleanBike = cleanData.bikes.find((b) => b.name === "Road Bike");
    if (cleanBike) {
      cleanBike.parts = (cleanBike.parts || []).filter((p) => p.name !== partName);
      await fetch(BIKE_CGI, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(cleanData) });
    }
  });

  test("email-alert-false-when-unchecked", async () => {
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
    const partName = `EmailAlertFalsePart-${Date.now()}`;
    await page.evaluate(() => {
      if (typeof _CFG !== "undefined") _CFG.emailConfigured = true;
      showAddPart();
    });
    await page.waitForSelector("#p-name", { timeout: 3000 });
    await page.$eval("#p-name", (el, v) => { el.value = v; }, partName);
    await page.evaluate(() => savePart(null));
    await page.evaluate(() => new Promise((r) => setTimeout(r, 1000)));
    const data = await fetch(BIKE_CGI, { cache: "no-store" }).then((r) => r.json());
    const bike = data.bikes.find((b) => b.name === "Road Bike");
    const newPart = (bike?.parts || []).find((p) => p.name === partName);
    expect(newPart, `Part "${partName}" not found in CGI store`).toBeTruthy();
    expect(!newPart.emailAlert, `expected emailAlert falsy on unchecked part, got: ${JSON.stringify(newPart.emailAlert)}`).toBeTruthy();
    // Cleanup
    const cleanData = await fetch(BIKE_CGI, { cache: "no-store" }).then((r) => r.json());
    const cb = cleanData.bikes.find((b) => b.name === "Road Bike");
    if (cb) {
      cb.parts = (cb.parts || []).filter((p) => p.name !== partName);
      await fetch(BIKE_CGI, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(cleanData) });
    }
  });
});

// ── Alert Thresholds ──────────────────────────────────────────────────────────

test.describe("alert-thresholds", () => {
  let page;
  let originalAlertKm;
  let skipSuite = false;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    // CGI setup: lower alertKm to 1 on first active part
    const setupR = await fetch(BIKE_CGI, { cache: "no-store" });
    const setupData = await setupR.json();
    const road = setupData.bikes.find((b) => b.name === "Road Bike");
    if (!road || !road.parts || road.parts.length === 0) {
      skipSuite = true;
      return;
    }
    const firstPart = road.parts[0];
    if (firstPart.serviceTypes && firstPart.serviceTypes.length > 0) {
      originalAlertKm = firstPart.serviceTypes[0].alertKm;
      firstPart.serviceTypes[0].alertKm = 1;
    } else {
      originalAlertKm = firstPart.alertKm;
      firstPart.alertKm = 1;
    }
    await fetch(BIKE_CGI, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(setupData),
    });

    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    jsErrors.length = 0;
    await page.evaluate(() => { try { sessionStorage.clear(); } catch (_) {} });
    await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    try {
      await page.waitForSelector(".bikes .tab", { timeout: 10000 });
      await page.waitForFunction(
        () => !document.getElementById("meta")?.textContent.includes("Loading"),
        { timeout: 10000 },
      );
    } catch (_) {}
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
    await page.evaluate(() => new Promise((r) => setTimeout(r, 300)));
  });

  test.afterAll(async () => {
    // CGI teardown: restore original alertKm
    const restoreR = await fetch(BIKE_CGI, { cache: "no-store" });
    const restoreData = await restoreR.json();
    const restoreRoad = restoreData.bikes.find((b) => b.name === "Road Bike");
    if (restoreRoad && restoreRoad.parts && restoreRoad.parts.length > 0) {
      const rp = restoreRoad.parts[0];
      if (rp.serviceTypes && rp.serviceTypes.length > 0) {
        rp.serviceTypes[0].alertKm = originalAlertKm;
      } else {
        rp.alertKm = originalAlertKm;
      }
      await fetch(BIKE_CGI, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(restoreData),
      });
    }
    if (page) await page.close();
  });

  test("warn-row-appears-when-threshold-exceeded", async () => {
    if (skipSuite) return;
    const n = await page.$$eval("#bikepanel tr.warn", (rows) => rows.length);
    expect(n >= 1, `expected >= 1 tr.warn in #bikepanel when alertKm=1 is set, got ${n}`).toBeTruthy();
  });

  test("warn-row-has-highlight-background", async () => {
    if (skipSuite) return;
    const bg = await page.evaluate(() => {
      const td = document.querySelector("#bikepanel tr.warn td");
      return td ? window.getComputedStyle(td).backgroundColor : null;
    });
    expect(
      bg && bg !== "rgba(0, 0, 0, 0)" && bg !== "transparent",
      `expected coloured background on tr.warn td, got: "${bg}"`,
    ).toBeTruthy();
  });
});

// ── Needs Replacement ──────────────────────────────────────────────────────────

test.describe("needs-replacement", () => {
  let page;
  let skipSuite = false;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    // CGI setup: clear needsReplacement on all parts
    const setupR = await fetch(BIKE_CGI, { cache: "no-store" });
    const setupData = await setupR.json();
    const road = setupData.bikes.find((b) => b.name === "Road Bike");
    if (!road || !road.parts || road.parts.length < 2) {
      skipSuite = true;
      return;
    }
    road.parts.forEach((p) => { p.needsReplacement = false; });
    await fetch(BIKE_CGI, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(setupData),
    });

    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    jsErrors.length = 0;
    await page.evaluate(() => { try { sessionStorage.clear(); } catch (_) {} });
    await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    try {
      await page.waitForSelector(".bikes .tab", { timeout: 10000 });
      await page.waitForFunction(
        () => !document.getElementById("meta")?.textContent.includes("Loading"),
        { timeout: 10000 },
      );
    } catch (_) {}
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
  });

  test.afterAll(async () => {
    // Teardown: clear all needsReplacement flags
    const tearR = await fetch(BIKE_CGI, { cache: "no-store" });
    const tearData = await tearR.json();
    const tearRoad = tearData.bikes.find((b) => b.name === "Road Bike");
    if (tearRoad) tearRoad.parts.forEach((p) => { p.needsReplacement = false; });
    await fetch(BIKE_CGI, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(tearData),
    });
    if (page) await page.close();
  });

  test("service-modal-has-needs-repl-checkbox", async () => {
    if (skipSuite) return;
    const svcBtns = await page.$$('#bikepanel tbody tr:not(.ridesrow) button[onclick*="showService"]');
    expect(svcBtns.length >= 1, "expected >= 1 Service button").toBeTruthy();
    await svcBtns[0].click();
    await page.waitForSelector("#s-needs-repl", { timeout: 3000 });
    const chk = await page.$("#s-needs-repl");
    expect(chk, "#s-needs-repl checkbox not found in service modal").toBeTruthy();
    await page.evaluate(() => closeModal());
  });

  test("needs-repl-badge-visible-after-flag", async () => {
    if (skipSuite) return;
    // Use CGI to mark last part as needsReplacement, then reload
    const preR = await fetch(BIKE_CGI, { cache: "no-store" });
    const preData = await preR.json();
    const preRoad = preData.bikes.find((b) => b.name === "Road Bike");
    if (preRoad && preRoad.parts.length >= 2) {
      preRoad.parts[preRoad.parts.length - 1].needsReplacement = true;
      await fetch(BIKE_CGI, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(preData),
      });
    }
    await page.reload({ waitUntil: "networkidle", timeout: 20000 });
    try {
      await page.waitForSelector(".bikes .tab", { timeout: 10000 });
      await page.waitForFunction(
        () => !document.getElementById("meta")?.textContent.includes("Loading"),
        { timeout: 10000 },
      );
    } catch (_) {}
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
    await page.evaluate(() => new Promise((r) => setTimeout(r, 300)));
    const n = await page.$$eval("#bikepanel .needs-repl", (els) => els.length);
    expect(n >= 1, `expected >= 1 .needs-repl badge in #bikepanel, got ${n}`).toBeTruthy();
  });

  test("flagged-part-sorts-first", async () => {
    if (skipSuite) return;
    const firstRowHasBadge = await page.evaluate(() => {
      const rows = document.querySelectorAll('#bikepanel .sec[data-sid="parts"] tbody tr:not(.ridesrow)');
      return rows.length > 0 && !!rows[0].querySelector(".needs-repl");
    });
    expect(firstRowHasBadge, "expected the flagged part to be the first row in the active-parts table").toBeTruthy();
  });

  test("service-modal-checkbox-prechecked-for-flagged-part", async () => {
    if (skipSuite) return;
    const svcBtns = await page.$$('#bikepanel .sec[data-sid="parts"] tbody tr:not(.ridesrow) button[onclick*="showService"]');
    expect(svcBtns.length >= 1, "no Service button found").toBeTruthy();
    await svcBtns[0].click();
    await page.waitForSelector("#s-needs-repl", { timeout: 3000 });
    const checked = await page.$eval("#s-needs-repl", (el) => el.checked);
    expect(checked, "#s-needs-repl should be pre-checked for a flagged part").toBeTruthy();
    await page.evaluate(() => closeModal());
  });
});

// ── Service Type Description ───────────────────────────────────────────────────

test.describe("service-type-description", () => {
  let page;
  let skipSuite = false;
  let testPartId, testDesc, origDesc;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    // CGI setup: write test description onto first serviceType
    const setupR = await fetch(BIKE_CGI, { cache: "no-store" });
    const setupData = await setupR.json();
    const road = setupData.bikes.find((b) => b.name === "Road Bike");
    if (!road || !road.parts || !road.parts.length ||
        !road.parts[0].serviceTypes || !road.parts[0].serviceTypes.length) {
      skipSuite = true;
      return;
    }
    const testPart = road.parts[0];
    testPartId = testPart.id;
    testDesc = `desc-${Date.now()}`;
    origDesc = testPart.serviceTypes[0].desc;
    testPart.serviceTypes[0].desc = testDesc;
    await fetch(BIKE_CGI, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(setupData),
    });

    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    jsErrors.length = 0;
    await page.evaluate(() => { try { sessionStorage.clear(); } catch (_) {} });
    await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    try {
      await page.waitForSelector(".bikes .tab", { timeout: 10000 });
      await page.waitForFunction(
        () => !document.getElementById("meta")?.textContent.includes("Loading"),
        { timeout: 10000 },
      );
    } catch (_) {}
    await page.evaluate(() => {
      const t = Array.from(document.querySelectorAll(".bikes .tab:not(.add)"))
        .find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    await page.waitForSelector("#bikepanel .big", { timeout: 5000 });
  });

  test.afterAll(async () => {
    // Restore original description
    const restoreR = await fetch(BIKE_CGI, { cache: "no-store" });
    const restoreData = await restoreR.json();
    const restoreRoad = restoreData.bikes.find((b) => b.name === "Road Bike");
    if (restoreRoad && restoreRoad.parts.length > 0 &&
        restoreRoad.parts[0].serviceTypes && restoreRoad.parts[0].serviceTypes.length > 0) {
      restoreRoad.parts[0].serviceTypes[0].desc = origDesc;
      await fetch(BIKE_CGI, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(restoreData),
      });
    }
    if (page) await page.close();
  });

  test("service-modal-shows-type-description", async () => {
    if (skipSuite) return;
    await page.evaluate((pid) => showService(pid), testPartId);
    await page.waitForSelector("#ovl", { timeout: 3000 });
    await page.evaluate(() => new Promise((r) => setTimeout(r, 150)));
    const descEl = await page.$("#s-type-desc");
    expect(descEl, "#s-type-desc not present in service modal").toBeTruthy();
    const text = await page.$eval("#s-type-desc", (el) => el.textContent.trim());
    expect(text, `service modal description mismatch: expected "${testDesc}", got "${text}"`).toBe(testDesc);
    await page.evaluate(() => closeModal());
  });
});

// ── Bike Section Order ─────────────────────────────────────────────────────────

test.describe("bike-section-order", () => {
  let page;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    await page.evaluate(() => {
      try { localStorage.removeItem("ssb-bike-sec"); } catch (_) {}
    });
    await page.goto(URLS.bike, { waitUntil: "networkidle", timeout: 20000 });
    await page.waitForSelector(".bikes .tab", { timeout: 10000 });
    await page.waitForFunction(
      () => !document.getElementById("meta")?.textContent.includes("Loading"),
      { timeout: 10000 },
    );
    await page.evaluate(() => {
      const tabs = document.querySelectorAll(".bikes .tab:not(.add)");
      const t = Array.from(tabs).find((el) => el.textContent.includes("Road Bike"));
      if (t) t.click();
    });
    try { await page.waitForSelector("#bikepanel .sec[data-sid]", { timeout: 8000 }); } catch (_) {}
    await page.evaluate(() => new Promise((r) => setTimeout(r, 300)));
  });

  test.afterAll(async () => {
    await page.evaluate(() => { try { localStorage.removeItem("ssb-bike-sec"); } catch (_) {} });
    await page.close();
  });

  test("no-js-errors", () => {
    expect(jsErrors.length, jsErrors.map((e) => e.message).join("; ")).toBe(0);
  });

  test("parts-section-present", async () => {
    const sid = await page.$eval("#bikepanel .sec[data-sid='parts']", (el) =>
      el.getAttribute("data-sid"),
    );
    expect(sid, "expected 'parts' section in bikepanel").toBe("parts");
  });

  test("drag-handles-present", async () => {
    const n = await page.$$eval("#bikepanel .sec .sec-handle", (els) => els.length);
    expect(n >= 1, `expected at least 1 .sec-handle in bikepanel, got ${n}`).toBeTruthy();
  });

  test("reset-button-present", async () => {
    const n = await page.$$eval("#bikepanel .sec-order-reset", (els) => els.length);
    expect(n, `expected 1 .sec-order-reset in bikepanel, got ${n}`).toBe(1);
  });

  test("drag-to-reorder-works-when-multiple-sections", async () => {
    const secCount = await page.$$eval("#bikepanel .sec[data-sid]", (els) => els.length);
    if (secCount < 2) return;
    await page.evaluate(() => {
      const panel = document.getElementById("bikepanel");
      const secs = Array.from(panel.querySelectorAll(".sec[data-sid]"));
      if (secs.length < 2) return;
      const src = secs[0], tgt = secs[1];
      const handle = src.querySelector(".sec-handle");
      if (!handle) return;
      handle.dispatchEvent(new Event("dragstart", { bubbles: true }));
      const rect = tgt.getBoundingClientRect();
      tgt.dispatchEvent(new MouseEvent("drop", { bubbles: true, cancelable: true, clientY: rect.top + rect.height - 1 }));
      handle.dispatchEvent(new Event("dragend", { bubbles: true }));
    });
    await page.evaluate(() => new Promise((r) => setTimeout(r, 100)));
    const sids = await page.$$eval("#bikepanel .sec[data-sid]", (els) =>
      els.map((el) => el.getAttribute("data-sid")),
    );
    const saved = await page.evaluate(() => {
      try { return JSON.parse(localStorage.getItem("ssb-bike-sec")); } catch (_) { return null; }
    });
    expect(Array.isArray(saved) && saved.length >= 1, "expected saved order in localStorage").toBeTruthy();
    expect(saved[0], `saved[0] should match DOM order[0]: "${sids[0]}"`).toBe(sids[0]);
  });

  test("reset-button-restores-default-order", async () => {
    await page.evaluate(() => {
      const rb = document.querySelector("#bikepanel .sec-order-reset");
      if (rb) rb.click();
    });
    await page.evaluate(() => new Promise((r) => setTimeout(r, 100)));
    const sids = await page.$$eval("#bikepanel .sec[data-sid]", (els) =>
      els.map((el) => el.getAttribute("data-sid")),
    );
    expect(sids[0], `after reset, expected "service-queue" first, got "${sids[0]}"`).toBe("service-queue");
  });
});

// ── Mobile Layout ──────────────────────────────────────────────────────────────

test.describe("mobile-layout", () => {
  let page;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
    await page.setViewportSize({ width: 375, height: 812 });
  });

  test.afterAll(async () => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.close();
  });

  const pages = [
    { name: "dashboard", url: "dash",     wait: "#board" },
    { name: "stats",     url: "stats",    wait: ".kpis .kpi" },
    { name: "bike",      url: "bike",     wait: ".bikes" },
    { name: "activity",  url: "activity", wait: "#content" },
  ];

  for (const pg of pages) {
    test(`${pg.name}-mobile-checks`, async () => {
      jsErrors.length = 0;
      await page.evaluate(() => {
        try { localStorage.removeItem("theme"); } catch (_) {}
        try { sessionStorage.clear(); } catch (_) {}
      });
      await page.goto(URLS[pg.url], { waitUntil: "networkidle", timeout: 20000 });
      try { await page.waitForSelector(pg.wait, { timeout: 10000 }); } catch (_) {}

      const overflow = await page.evaluate(() =>
        document.documentElement.scrollWidth > document.documentElement.clientWidth
      );
      expect(!overflow,
        `${pg.name} page has horizontal overflow at 375px — table needs overflow-x:auto wrapper`).toBeTruthy();

      const hdr = await page.$("#hdr");
      expect(hdr, `#hdr element not found on ${pg.name} page`).toBeTruthy();

      expect(jsErrors.length, `JS errors on ${pg.name} at 375px: ${jsErrors.map((e) => e.message).join("; ")}`).toBe(0);
    });
  }
});

// ── Mobile Section Reorder ────────────────────────────────────────────────────

test.describe("mobile-section-reorder", () => {
  let ctx, mPage;

  test.beforeAll(async ({ browser }) => {
    ctx = await browser.newContext({ isMobile: true, hasTouch: true, viewport: { width: 375, height: 812 } });
    mPage = await ctx.newPage();
  });

  test.afterAll(async () => { await ctx.close(); });

  const mobilePages = [
    { name: "stats",    url: "stats",    wait: ".kpis .kpi" },
    { name: "activity", url: "activity", wait: "#content" },
    { name: "bike",     url: "bike",     wait: ".bikes" },
    { name: "club",     url: "club",     wait: ".club-section" },
  ];

  for (const pg of mobilePages) {
    test(`${pg.name}-handle-hidden-on-mobile`, async () => {
      await mPage.goto(URLS[pg.url], { waitUntil: "networkidle", timeout: 20000 });
      try { await mPage.waitForSelector(pg.wait, { timeout: 10000 }); } catch (_) {}
      const visible = await mPage.evaluate(() => {
        return Array.from(document.querySelectorAll(".sec-handle")).some(el => {
          const s = getComputedStyle(el);
          return s.display !== "none" && s.visibility !== "hidden";
        });
      });
      expect(!visible, `${pg.name}: .sec-handle should be hidden on touch viewport but is visible`).toBeTruthy();
    });

    test(`${pg.name}-reset-btn-hidden-on-mobile`, async () => {
      const visible = await mPage.evaluate(() => {
        return Array.from(document.querySelectorAll(".sec-order-reset")).some(el => {
          const s = getComputedStyle(el);
          return s.display !== "none" && s.visibility !== "hidden";
        });
      });
      expect(!visible, `${pg.name}: .sec-order-reset should be hidden on touch viewport but is visible`).toBeTruthy();
    });
  }
});

// ── Dark Mode ──────────────────────────────────────────────────────────────────

test.describe("dark-mode", () => {
  let page;
  const jsErrors = [];

  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage();
    page.on("pageerror", (e) => jsErrors.push(e));
  });

  test.afterAll(async () => { await page.close(); });

  const dmPages = [
    { name: "dashboard",   url: "dash",     wait: "#board table" },
    { name: "stats",       url: "stats",    wait: ".kpis .kpi" },
    { name: "bike",        url: "bike",     wait: ".bikes .tab" },
    { name: "activity",    url: "activity", wait: "#content" },
    { name: "leaderboard", url: "club",     wait: "#board" },
  ];

  for (const pg of dmPages) {
    test(`${pg.name}-dark-mode-checks`, async () => {
      jsErrors.length = 0;
      await page.evaluate(() => {
        try { localStorage.removeItem("theme"); } catch (_) {}
        try { sessionStorage.clear(); } catch (_) {}
      });
      await page.goto(URLS[pg.url], { waitUntil: "networkidle", timeout: 20000 });
      try { await page.waitForSelector(pg.wait, { timeout: 10000 }); } catch (_) {}

      // toggle button exists
      const btn = await page.$("#theme-tog");
      expect(btn, `#theme-tog not found on ${pg.name} page`).toBeTruthy();

      // initial icon is 🌙 or ☀️
      const icon = await page.$eval("#theme-tog", (el) => el.textContent.trim());
      expect(icon === "🌙" || icon === "☀️",
        `expected 🌙 or ☀️ from #theme-tog on ${pg.name}, got: "${icon}"`).toBeTruthy();

      // click from light → dark
      await page.evaluate(() => {
        document.documentElement.dataset.theme = "light";
        localStorage.setItem("theme", "light");
        document.getElementById("theme-tog").textContent = "🌙";
      });
      await page.click("#theme-tog");
      await page.evaluate(() => new Promise((r) => setTimeout(r, 50)));
      const theme1 = await page.evaluate(() => document.documentElement.dataset.theme);
      expect(theme1, `clicking #theme-tog from light should set data-theme=dark on ${pg.name}`).toBe("dark");
      const icon1 = await page.$eval("#theme-tog", (el) => el.textContent.trim());
      expect(icon1, `icon after dark toggle should be ☀️ on ${pg.name}, got "${icon1}"`).toBe("☀️");

      // click again → light
      await page.click("#theme-tog");
      await page.evaluate(() => new Promise((r) => setTimeout(r, 50)));
      const theme2 = await page.evaluate(() => document.documentElement.dataset.theme);
      expect(theme2, `second click on #theme-tog should set data-theme=light on ${pg.name}`).toBe("light");

      // persists to localStorage
      await page.evaluate(() => {
        document.documentElement.dataset.theme = "light";
        localStorage.setItem("theme", "light");
        document.getElementById("theme-tog").textContent = "🌙";
      });
      await page.click("#theme-tog"); // → dark
      await page.evaluate(() => new Promise((r) => setTimeout(r, 50)));
      const stored = await page.evaluate(() => localStorage.getItem("theme"));
      expect(stored, `localStorage["theme"] should be "dark" after clicking to dark on ${pg.name}`).toBe("dark");

      // reload preserves theme
      await page.reload({ waitUntil: "networkidle", timeout: 20000 });
      try { await page.waitForSelector(pg.wait, { timeout: 10000 }); } catch (_) {}
      const themeAfterReload = await page.evaluate(() => document.documentElement.dataset.theme);
      expect(themeAfterReload, `after reload, data-theme should still be "dark" on ${pg.name}`).toBe("dark");

      // cleanup
      await page.evaluate(() => { try { localStorage.removeItem("theme"); } catch (_) {} });

      // no js errors
      expect(jsErrors.length, `JS errors on ${pg.name}: ${jsErrors.map((e) => e.message).join("; ")}`).toBe(0);
    });
  }
});
